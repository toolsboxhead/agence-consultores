<x-platform title="Home">
    <h1>Main</h1>
</x-platform>
