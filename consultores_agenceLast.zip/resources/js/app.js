import "./bootstrap";
import "../scss/app.scss";
import jQuery from "jquery";
window.$ = jQuery;
