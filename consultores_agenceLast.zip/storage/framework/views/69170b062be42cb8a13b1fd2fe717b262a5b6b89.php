<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.platform','data' => ['title' => 'Comercial']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('platform'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Comercial']); ?>


    
    <div class="card">
        <div class="card-header">
            Consultores
        </div>
        <div class="card-body">
            <div class="row m-2">
                <div class="col-1  d-flex justify-content-center p-1">Período</div>
                <div class="col-7  d-flex justify-content-left p-1">
                    
                    <select id="meses" class="form-select form-select-sm" aria-label=".form-select-sm example">
                        <?php for($i = 1; $i <= 12; $i++): ?>
                            <option value="<?php echo e($i); ?>"><?php echo e(nombreMes($i)); ?></option>
                        <?php endfor; ?>
                    </select>
                    
                    <select id="anios"class="form-select form-select-sm" aria-label=".form-select-sm example"">
                        <?php for($anio = 2003; $anio <= 2008; $anio++): ?>
                            <option value="<?php echo e($anio); ?>"><?php echo e($anio); ?></option>
                        <?php endfor; ?>
                    </select>
                    <p> A </p>
                    
                    <select id="meses2" class="form-select form-select-sm" aria-label=".form-select-sm example">
                        <?php for($i = 1; $i <= 12; $i++): ?>
                            <option value="<?php echo e($i); ?>"><?php echo e(nombreMes($i)); ?></option>
                        <?php endfor; ?>
                    </select>
                    
                    <select id="anios2" class="form-select form-select-sm" aria-label=".form-select-sm example">
                        <?php for($anio2 = 2003; $anio2 <= 2008; $anio2++): ?>
                            <option value="<?php echo e($anio2); ?>"><?php echo e($anio2); ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="col md-2  d-flex justify-content-center p-1"></div>
            </div>

            <div class="row m-2  d-flex justify-content-center p-3">
                <div class="col-1 d-flex align-self-center">
                    <p class="text-break">Consultores</p>
                </div>
                <div class="col-9    justify-content-center">
                    <form id="demoform" action="#" method="POST">
                        <?php echo csrf_field(); ?>

                        <select multiple="multiple" size="6" name="duallistbox_permissions[]" id="test">
                            <?php $__currentLoopData = $consults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value=<?php echo e($consult->co_usuario); ?>><?php echo e($consult->no_usuario); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                    </form>
                </div>
                <div class="col-2  d-flex ">
                    <div class="buttons align-self-center">
                        <div class="col-md-4">
                            <div class="btn-group-vertical">
                                <input type="button" class="btn btn-primary btn-sm btn-block mb-1" value="Relatório"
                                    id="tabla" />
                                <input type="button" class="btn btn-primary btn-sm btn-block" value="Gráfico"
                                    id="g-bar" />
                                <input type="button" class="btn btn-primary btn-sm btn-block mt-1" value="Pizza"
                                    id="g-area" />
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <div class="datos row m-3">
        <div class="tabla-datos" id="tabla-datos">


        </div>
        <div class="contenedor-html">

        </div>
    </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.0.0  "></script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH D:\proyectos\laravel\consultores_agence\resources\views/comercial/perf_comercial.blade.php ENDPATH**/ ?>