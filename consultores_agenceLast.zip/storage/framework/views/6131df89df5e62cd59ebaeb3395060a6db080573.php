<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.platform','data' => ['title' => 'Tabla']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('platform'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Tabla']); ?>
    <div>
        <form action="<?php echo e(route('datosview')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <label for="nombreUsuario">Codigo de Usuario</label>
            <input type="text" name="nombreUsuario" id="nombreUsuario">
            <button type="submit">Enviar</button>

        </form>
        <h1>Datos del Usuario1</h1>
        <ul>
            <?php if(isset($datos)): ?>
                <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>Codigo : <?php echo e($dato->co_usuario); ?>,</li>
                    <li>Nombre : <?php echo e($dato->no_usuario); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p>No hay datos disponibles actualmente.</p>
            <?php endif; ?>

        </ul>
        

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH D:\proyectos\laravel\consultores_agence\resources\views/comercial/datosview.blade.php ENDPATH**/ ?>