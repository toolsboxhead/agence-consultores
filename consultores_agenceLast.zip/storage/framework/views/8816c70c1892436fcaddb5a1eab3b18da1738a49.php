<table Class="table table-striped">
    <caption>Tabla Resumen de Desempeño</caption>
    <thead>
        <th>Per&iacuteodo</th>
        <th>Período</th>
        <th>Receita L&iacutequida</th>
        <th>Custo Fixo</th>
        <th>Comiss&atildeo</th>
        <th>Lucro</th>
    </thead>
    <tbody>
        <p><?php echo e($prefijo); ?></p>
        <p><?php echo e($mostrarTablaDatos); ?></p>
        
        <tr>
            <td>SALDO</td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
    </tbody>
<?php /**PATH D:\proyectos\laravel\consultores_agence\resources\views/comercial/tabla.blade.php ENDPATH**/ ?>