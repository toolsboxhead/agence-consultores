<div>Inicio</div>
<h2>
    <p>TITULO</p>
</h2>
<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Fugiat voluptatem placeat sunt nesciunt quisquam illum
    accusamus molestias delectus soluta dolor consequuntur, quas omnis et laudantium, minima reiciendis? Mollitia,
    veniam sed!</p>
<div>
    <p>Final <?php echo e($datos); ?> </p>

</div>
<?php /**PATH D:\proyectos\laravel\consultores_agence\resources\views/comercial/vview.blade.php ENDPATH**/ ?>