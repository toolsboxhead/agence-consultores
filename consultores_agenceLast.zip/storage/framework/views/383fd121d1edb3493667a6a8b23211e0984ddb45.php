<h2>
    Resultados:</h2>
<table Class="table table-striped">
    <caption>Tabla Resumen de Desempeño</caption>
    <thead>

    </thead>
    <tbody>

        <?php if(isset($datos)): ?>

            <?php
                $sameConsultor = false;
                $firstCons = true;
                $total_RL = 0;
                $total_SB = 0;
                $total_CO = 0;
                $total_LU = 0;
            ?>


            <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(!$firstCons): ?>
                    <?php
                        $sameConsultor = $dato->nom_user == $consultorAnte ? true : false;
                    ?>
                <?php endif; ?>

                <?php if(!$sameConsultor): ?>
                    <?php if(!$firstCons): ?>
                        <tr>
                            <th>SALDO</th>
                            <th><?php echo e(formatoMoneda($total_RL)); ?></th>
                            <th><?php echo e(formatoMoneda($total_SB)); ?></th>
                            <th><?php echo e(formatoMoneda($total_CO)); ?></th>
                            <th><?php echo e(formatoMoneda($total_LU)); ?></th>

                        </tr>
                    <?php endif; ?>
                    <?php
                        $firstCons = false;
                    ?>
                    <tr>
                        <th><?php echo e($dato->nom_user); ?></th>
                    </tr>
                    <tr>
                        <th>Período</th>
                        <th>Receita Líquida</th>
                        <th>Custo Fixol</th>
                        <th>Comissão</th>
                        <th>Lucro</th>
                    </tr>
                    <tr>
                        <td><?php echo e(nombreMes($dato->mes, true) . ' - ' . $dato->annio); ?></td>
                        <td><?php echo e(formatoMoneda($dato->receita_liquida)); ?> </td>
                        <td><?php echo e(formatoMoneda($dato->sal_bruto)); ?></td>
                        <td><?php echo e(formatoMoneda($dato->comissao)); ?></td>
                        <td><?php echo e(formatoMoneda($dato->lucro)); ?></td>
                        <?php
                            $total_RL = 0;
                            $total_SB = 0;
                            $total_CO = 0;
                            $total_LU = 0;

                            $total_RL += $dato->receita_liquida;
                            $total_SB += $dato->sal_bruto;
                            $total_CO += $dato->comissao;
                            $total_LU += $dato->lucro;
                            $sameConsultor = true;
                            $consultorAnte = $dato->nom_user;
                        ?>
                    </tr>
                <?php else: ?>
                    <tr>
                        <td><?php echo e(nombreMes($dato->mes, true) . ' - ' . $dato->annio); ?></td>
                        <td><?php echo e(formatoMoneda($dato->receita_liquida)); ?> </td>
                        <td><?php echo e(formatoMoneda($dato->sal_bruto)); ?></td>
                        <td><?php echo e(formatoMoneda($dato->comissao)); ?></td>
                        <td><?php echo e(formatoMoneda($dato->lucro)); ?></td>
                        <?php
                            $total_RL += $dato->receita_liquida;
                            $total_SB += $dato->sal_bruto;
                            $total_CO += $dato->comissao;
                            $total_LU += $dato->lucro;
                        ?>
                    </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th>SALDO</th>
                <th><?php echo e(formatoMoneda($total_RL)); ?></th>
                <th><?php echo e(formatoMoneda($total_SB)); ?></th>
                <th><?php echo e(formatoMoneda($total_CO)); ?></th>
                <th><?php echo e(formatoMoneda($total_LU)); ?></th>

            </tr>
        <?php else: ?>
            <p>No hay datos disponibles actualmente.</p>
        <?php endif; ?>
    </tbody>
</table>
<?php /**PATH D:\proyectos\laravel\consultores_agence\resources\views/comercial/datos_perfomance.blade.php ENDPATH**/ ?>